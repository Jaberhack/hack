# Kumpulan Script Script
- cek-kapasitas-hdd.sh : Script pengecekan kapasitas harddisk : Contoh penggunaan script : https://imanudin.com/2017/02/05/script-sederhana-pengecekan-kapasitas-harddisk-dan-kirim-hasilnya-via-email/
- cek-zimbra-status.sh : Script pengecekan status Zimbra : Contoh penggunaan script : https://imanudin.com/2017/02/02/script-sederhana-pengecekan-status-zimbra-dan-kirim-hasilnya-via-email/
- cek-expire-password-zimbra.sh : Script notifikasi expire password account Zimbra : Contoh penggunaan script : https://imanudin.com/2017/02/06/script-notifikasi-password-expire-pada-zimbra-mail-server/
- check_zimbra.pl :  Script cek status Zimbra dengan bahasa Perl : Contoh penggunaan script : https://imanudin.net/2017/02/23/script-automatic-restart-services-when-zimbra-stoppednot-running/
- otomatis_restart_zimbra.sh : Kombinasi script check_zimbra.pl untuk otomatis restart services : Contoh penggunaan script : https://imanudin.net/2017/02/23/script-automatic-restart-services-when-zimbra-stoppednot-running/
